/**
 * <Main class>
 *  
 * CSC1351 Programming Project Part 1
 * Section 2
 * 
 * @author <Alex Lam>
 * @since <March 17 2024
 * 
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Prog01_aOrderedList {

	public static void main(String[] args) {
        try {
            // Get input file from user
            Scanner scanner = GetInputFile("Enter input filename:");
            
            // Create an instance of the ordered list
            aOrderedList orderedList = new aOrderedList();
            
            // Process each line of the input file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (!line.isEmpty()) {
                    char operation = line.charAt(0);
                    if (operation == 'A' && line.split(",").length == 4) {
                        // Add a car to the ordered list
                        String[] parts = line.split(",");
                        String make = parts[1];
                        int year = Integer.parseInt(parts[2]);
                        int price = Integer.parseInt(parts[3]);
                        orderedList.add(new Car(make, year, price));
                    } else if (operation == 'D' && line.split(",").length == 2) {
                        // Remove a car from the ordered list
                        int index = Integer.parseInt(line.split(",")[1]);
                        orderedList.remove(index);
                    }
                }
            }
            
            // Print the ordered list to console
            System.out.println(orderedList);
            
            // Get output filename from user
            System.out.println("Enter output filename: ");
            String fileName = scanner.nextLine();
            
            // Write the ordered list to the output file
            try {
                PrintWriter writer = GetOutputFile(fileName);
                if (writer != null) {
                    writer.println("Number of cars: " + orderedList.size());
                    writer.println();
                    for (int i = 0; i < orderedList.size(); i++) {
                        Comparable compare = orderedList.get(i);
                        Car car = (Car) compare;
                        writer.println("Make: " + car.getMake());
                        writer.println("Year: " + car.getYear());
                        writer.println("Price: " + car.getPrice());
                        writer.println();
                    }
                    writer.close();
                } else {
                    System.out.println("Error creating PrintWriter. Writer is null.");
                }
            } catch (FileNotFoundException e) {
                System.out.println("Error: Output file not found.");
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
    }

    public static Scanner GetInputFile(String userPrompt) throws FileNotFoundException {
        Scanner userIn = new Scanner(System.in);
        while (true) {
            System.out.println(userPrompt);
            String fileName = userIn.nextLine();
            File file = new File(fileName);
            if (file.exists()) {
                return new Scanner(file);
            } else {
                System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N>  ");
                Scanner confirm = new Scanner(System.in);
                String answer = confirm.next();
                if (!answer.equalsIgnoreCase("Y")) {
                    System.out.println("User terminated program");
                    throw new FileNotFoundException();
                }
            }
        }
    }
    /**
    * <Method to get input file from user>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public static PrintWriter GetOutputFile(String userPrompt) throws FileNotFoundException {
        Scanner userIn = new Scanner(System.in);
        PrintWriter writer = null;
        boolean answer = false;
        while (!answer) {
            try {
                String fileName = userPrompt;
                writer = new PrintWriter(fileName);
                answer = true;
            } catch (FileNotFoundException e) {
                System.out.println("Error creating file. Would you like to enter a new file name? <Y/N> ");
                String A = userIn.nextLine().toLowerCase();
                if (!A.equals("Y")) {
                    throw e;
                }
            }
        }
        return writer;
    }
    /**
    * <Method to get output file from user>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */
}



   

 
		   
	 
	 
	 


	 

	 
	 
	 
