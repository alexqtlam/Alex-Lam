/**
 * <Car class>
 *  
 * CSC1351 Programming Project Part 1
 * Section 2
 * 
 * @author <Alex Lam>
 * @since <March 17 2024
 * 
 */
public class Car implements Comparable<Car> {
	private String make;
    private int year;
    private int price;

    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }
    /**
    * <Constructs a new Car object with the specified make, year, and price>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public String getMake() {
        return this.make;
    }
    /**
    * <Gets the make of the car>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public int getYear() {
        return this.year;
    }
    /**
    * <Gets the year of the car>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public int getPrice() {
        return this.price;
    }
    /**
    * <Gets the price of the car>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */
    
    @Override
    public int compareTo(Car otherCar) {
        // Compare by make first
        int makeComparison = this.make.compareTo(otherCar.make);
        if (makeComparison != 0) {
            return makeComparison;
        }
        
        // If make is the same, compare by year
        int yearComparison = Integer.compare(this.year, otherCar.year);
        if (yearComparison != 0) {
            return yearComparison;
        }
        
        // If make and year are the same, compare by price
        return Integer.compare(this.price, otherCar.price);
    }
    /**
    * <Compares this Car object with another Car object based on make, year, and price.>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    @Override
    public String toString() {
        return "Make: " + make + ", Year: " + year + ", Price: " + price + ";";
    }
}


