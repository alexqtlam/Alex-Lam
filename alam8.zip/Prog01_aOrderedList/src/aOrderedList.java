/**
 * <aOrderedList class>
 *  
 * CSC1351 Programming Project Part 1
 * Section 2
 * 
 * @author <Alex Lam>
 * @since <March 17 2024
 * 
 */
import java.util.Arrays;
import java.io.File;


public class aOrderedList {
    private final int SIZEINCREMENTS = 20; // size of increments for increasing ordered list
    private Comparable[] oList; // the ordered list
    private int listSize; // the size of the ordered list
    private int numObjects; // the number of objects in the ordered list
    private int curr; // current index for iteration

    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Comparable[SIZEINCREMENTS]; // Initialization of oList array with SIZEINCREMENTS size
        curr = 0; // initialize curr to start iteration
    }

    private void increaseListSize() {
        // Increase the size of the array by SIZEINCREMENTS
        listSize += SIZEINCREMENTS;
        oList = Arrays.copyOf(oList, listSize);
    }
    /**
    * <Increases the size of the array by SIZEINCREMENTS>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("[");
        for (int i = 0; i < numObjects; i++) {
            if (i > 0) {
                result.append(", ");
            }
            Comparable c = oList[i];
            result.append("[").append(c.toString()).append("]");
        }
        result.append("]");
        return result.toString();
    }
    /**
    * <Returns a string representation of the ordered list>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public int size() {
        return numObjects;
    }
    /**
    * <Returns the number of objects in the ordered list>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public Comparable get(int index) {
        return oList[index];
    }
    /**
    * <Returns the object at the specified index in the ordered list>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */
    

    public boolean isEmpty() {
        return numObjects == 0;
    }
    /**
    * <Checks if the ordered list is empty>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public void remove(int index) {
        for (int i = index + 1; i < numObjects; i++) {
            oList[i - 1] = oList[i];
        }
        numObjects--;
    }
    /**
    * <Removes the object at the specified index from the ordered list>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

  

    public void add(Comparable newObject) {
        if (numObjects == listSize) {
            increaseListSize();
        }
        int index = 0;
        while (index < numObjects && oList[index].compareTo(newObject) < 0) {
            index++;
        }

        for (int i = numObjects - 1; i >= index; i--) {
            oList[i + 1] = oList[i];
        }

        oList[index] = newObject;
        numObjects++;
    }
    /**
    * <Adds a new object to the ordered list>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public void reset() {
        curr = 0;
    }
    /**
    * <Resets the current index for iteration>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public Comparable next() {
        return oList[curr++];
    }
    /**
    * <Returns the next object in the ordered list for iteration>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public boolean hasNext() {
        return curr < numObjects;
    }
    /**
    * <Checks if there is a next object in the ordered list for iteration>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */

    public int getCarIndex(String make, int year) {
        for (int i = 0; i < numObjects; i++) {
            if (oList[i] instanceof Car) {
                Car car = (Car) oList[i];
                if (car.getMake().equals(make) && car.getYear() == year) {
                    return i;
                }
            }
        }
        return -1;
    }
    /**
    * <Returns the index of the car with the specified make and year in the ordered list>
    *
    * CSC 1351 Programming Project No <1>
    * Section <2>
    *
    * @author <Alex Lam>
    * @since <March 18 2024>
    *
    */
}